import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const EmmaApp());

class EmmaApp extends StatelessWidget {
  const EmmaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'EMMA ICT LEARN HUB',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
    home: const AppShell(),
  );
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override State<AppShell> createState() => _AppShellState();
}
class _AppShellState extends State<AppShell> {
  int tab=0;
  final pages=const [HomePage(), CoursesPage(), QuizListPage(), ProgressPage(), ProfilePage()];
  @override Widget build(BuildContext context)=>Scaffold(
    body: pages[tab],
    bottomNavigationBar: NavigationBar(
      selectedIndex: tab,
      onDestinationSelected:(i)=>setState(()=>tab=i),
      destinations: const [
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.menu_book_outlined),selectedIcon:Icon(Icons.menu_book),label:'Courses'),
        NavigationDestination(icon:Icon(Icons.quiz_outlined),selectedIcon:Icon(Icons.quiz),label:'Quiz'),
        NavigationDestination(icon:Icon(Icons.bar_chart_outlined),selectedIcon:Icon(Icons.bar_chart),label:'Progress'),
        NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile'),
      ],
    ),
  );
}

const courses=[
  Course('Computer Fundamentals','Learn the basic concepts of computers, hardware, software and operating systems.',Icons.computer),
  Course('Programming','Understand algorithms, programming concepts, variables, selection and repetition.',Icons.code),
  Course('Database Management','Learn data, databases, tables, keys, relationships and SQL fundamentals.',Icons.storage),
  Course('Computer Networking','Explore networks, devices, protocols, addressing and network security.',Icons.lan),
  Course('Web Development','Build web pages using HTML, CSS and basic JavaScript concepts.',Icons.language),
  Course('Cyber Security','Learn security principles, threats, protection and responsible ICT use.',Icons.security),
];

class Course {
  final String name, description; final IconData icon;
  const Course(this.name,this.description,this.icon);
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
    const Text('EMMA ICT LEARN HUB',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
    const Text('Learn ICT. Build Skills. Shape Your Future.',style:TextStyle(color:Colors.black54)),
    const SizedBox(height:20),
    Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Welcome back!',style:TextStyle(fontSize:23,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),const Text('Study anywhere, even when you are offline.'),
      const SizedBox(height:15),FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CourseDetailPage(course:courses[0]))),icon:const Icon(Icons.play_arrow),label:const Text('Start Learning'))
    ]))),
    const SizedBox(height:20),const Text('Popular Courses',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),...courses.take(4).map((c)=>CourseTile(course:c))
  ]));
}

class CoursesPage extends StatelessWidget {
  const CoursesPage({super.key});
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
    const Text('ICT Courses',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    const SizedBox(height:6),const Text('Select a course to begin.'),
    const SizedBox(height:15),...courses.map((c)=>CourseTile(course:c))
  ]));
}
class CourseTile extends StatelessWidget {
  final Course course; const CourseTile({super.key,required this.course});
  @override Widget build(BuildContext context)=>Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(
    leading:CircleAvatar(child:Icon(course.icon)),title:Text(course.name,style:const TextStyle(fontWeight:FontWeight.bold)),
    subtitle:Text(course.description,maxLines:2,overflow:TextOverflow.ellipsis),trailing:const Icon(Icons.chevron_right),
    onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CourseDetailPage(course:course)))
  ));
}

class CourseDetailPage extends StatelessWidget {
  final Course course; const CourseDetailPage({super.key,required this.course});
  @override Widget build(BuildContext context){
    final topics=[
      'Introduction and key concepts','Terminology and components','Practical examples',
      'Hands-on activity','Review questions'
    ];
    return Scaffold(appBar:AppBar(title:Text(course.name)),body:ListView(padding:const EdgeInsets.all(20),children:[
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Icon(course.icon,size:44),const SizedBox(height:10),Text(course.name,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
        const SizedBox(height:7),Text(course.description)
      ]))),
      const SizedBox(height:18),const Text('Lessons',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),...topics.asMap().entries.map((e)=>Card(child:ListTile(
        leading:CircleAvatar(child:Text('${e.key+1}')),title:Text(e.value),trailing:const Icon(Icons.arrow_forward_ios,size:16),
        onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LessonPage(course:course,title:e.value)))
      )))
    ]));
  }
}

class LessonPage extends StatelessWidget {
  final Course course; final String title;
  const LessonPage({super.key,required this.course,required this.title});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(title)),body:ListView(padding:const EdgeInsets.all(20),children:[
    Text(title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
    const SizedBox(height:14),
    Text('In this lesson, you will study ${course.name.toLowerCase()} through clear explanations and practical examples.',style:const TextStyle(fontSize:16,height:1.5)),
    const SizedBox(height:18),
    const Text('Learning objectives',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),
    const Text('• Define important ICT terms.\n• Explain the main concepts.\n• Apply the knowledge to a practical situation.\n• Answer practice questions.',style:TextStyle(fontSize:16,height:1.7)),
    const SizedBox(height:20),
    Card(child:Padding(padding:const EdgeInsets.all(16),child:const Text(
      'Study tip: Read the lesson, write short notes in your own words, then attempt the quiz without looking at the answers.',
      style:TextStyle(fontSize:15,height:1.5)
    ))),
    const SizedBox(height:16),
    FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const QuizPage())),
      icon:const Icon(Icons.quiz),label:const Text('Take Practice Quiz'))
  ]));
}

class Question {
  final String q; final List<String> options; final int answer;
  const Question(this.q,this.options,this.answer);
}
const quizQuestions=[
  Question('Which component is commonly used to process instructions in a computer?',['Monitor','CPU','Keyboard','Printer'],1),
  Question('Which of these is an example of system software?',['Operating system','Spreadsheet','Presentation','Web page'],0),
  Question('What does ICT stand for?',['Information and Communication Technology','Internet Computer Training','Information Control Tool','Integrated Computer Terminal'],0),
  Question('Which device is mainly used to enter text?',['Monitor','Keyboard','Speaker','Projector'],1),
  Question('Which one is a programming language?',['HTML','Python','HTTP','Wi-Fi'],1),
];

class QuizListPage extends StatelessWidget {
  const QuizListPage({super.key});
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
    const Text('Quizzes',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),const Text('Test your understanding and save your best score on this device.'),
    const SizedBox(height:16),Card(child:ListTile(
      leading:const CircleAvatar(child:Icon(Icons.computer)),title:const Text('ICT Fundamentals Quiz'),
      subtitle:const Text('5 questions • Automatic marking'),
      trailing:FilledButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const QuizPage())),child:const Text('Start'))
    ))
  ]));
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});
  @override State<QuizPage> createState()=>_QuizPageState();
}
class _QuizPageState extends State<QuizPage>{
  int current=0,score=0; int? selected;
  void choose(int i){if(selected!=null)return; setState(()=>selected=i);}
  Future<void> next() async {
    if(selected==null)return;
    if(selected==quizQuestions[current].answer)score++;
    if(current<quizQuestions.length-1){setState((){current++;selected=null;});}
    else{
      final p=await SharedPreferences.getInstance();
      final old=p.getInt('best_score')??0;
      if(score>old)await p.setInt('best_score',score);
      if(!mounted)return;
      showDialog(context:context,barrierDismissible:false,builder:(_)=>AlertDialog(
        title:const Text('Quiz Complete'),
        content:Text('Your score is $score/${quizQuestions.length}.'),
        actions:[TextButton(onPressed:(){Navigator.pop(context);Navigator.pop(context);},child:const Text('Done'))]
      ));
    }
  }
  @override Widget build(BuildContext context){
    final q=quizQuestions[current];
    return Scaffold(appBar:AppBar(title:Text('Question ${current+1}/${quizQuestions.length}')),body:ListView(padding:const EdgeInsets.all(20),children:[
      LinearProgressIndicator(value:(current+1)/quizQuestions.length),
      const SizedBox(height:25),Text(q.q,style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold)),
      const SizedBox(height:18),...q.options.asMap().entries.map((e){
        final correct=selected!=null&&e.key==q.answer;
        final wrong=selected==e.key&&e.key!=q.answer;
        return Card(color:correct?Colors.green.withOpacity(.15):wrong?Colors.red.withOpacity(.12):null,child:ListTile(
          title:Text(e.value),leading:Radio<int>(value:e.key,groupValue:selected,onChanged:(_)=>choose(e.key)),
          onTap:()=>choose(e.key)
        ));
      }),
      const SizedBox(height:15),FilledButton(onPressed:selected==null?null:next,child:Text(current==quizQuestions.length-1?'Finish':'Next'))
    ]));
  }
}

class ProgressPage extends StatefulWidget {
  const ProgressPage({super.key});
  @override State<ProgressPage> createState()=>_ProgressPageState();
}
class _ProgressPageState extends State<ProgressPage>{
  int best=0;
  @override void initState(){super.initState();load();}
  Future<void> load()async{final p=await SharedPreferences.getInstance();setState(()=>best=p.getInt('best_score')??0);}
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
    const Text('My Progress',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:16),
    Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
      const Text('Best Quiz Score',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      const SizedBox(height:10),Text('$best / ${quizQuestions.length}',style:const TextStyle(fontSize:32,fontWeight:FontWeight.bold)),
      const SizedBox(height:10),LinearProgressIndicator(value:best/quizQuestions.length)
    ]))),
    const SizedBox(height:12),const Card(child:ListTile(leading:Icon(Icons.offline_bolt),title:Text('Offline-ready'),subtitle:Text('Quiz score is stored locally on the device.')))
  ]));
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
    const CircleAvatar(radius:45,child:Icon(Icons.person,size:48)),const SizedBox(height:12),
    const Center(child:Text('Student Profile',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold))),
    const SizedBox(height:20),
    const ListTile(leading:Icon(Icons.badge),title:Text('Name'),subtitle:Text('Student')),
    const ListTile(leading:Icon(Icons.school),title:Text('College'),subtitle:Text('Your College')),
    const ListTile(leading:Icon(Icons.computer),title:Text('Programme'),subtitle:Text('Information & Communication Technology')),
    const Divider(),const ListTile(leading:Icon(Icons.cloud_off),title:Text('Offline learning'),subtitle:Text('Lessons and quiz progress can work without internet.'))
  ]));
}
