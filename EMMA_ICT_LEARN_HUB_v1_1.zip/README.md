# EMMA ICT LEARN HUB v1.1

This version adds:
- Real lesson screens
- Five-question ICT Fundamentals quiz
- Automatic marking
- Best-score persistence using SharedPreferences
- Progress screen showing saved best score
- Offline-friendly local score storage
- Android and Web Flutter structure

Run:
flutter pub get
flutter run

For web:
flutter run -d chrome
